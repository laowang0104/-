#!/bin/env bash
mkdir -p /usr/node
cp -r /root/tiantang/node/* /usr/node
#\cp -rf  /root/tiantang/etc/* /etc
chmod 777 /etc/fstab && chmod 777 /etc/rc.local && chmod 777 /etc/network/interfaces && chmod -R 777 /usr/node
echo  "\033[36m _   _     ____   ___   ___  ____  \033[0m "
echo  "\033[36m| |_| |_  / ___| ( _ ) /\033[0m\033[34m _ \| ___| \033[0m"
echo  "\033[36m| __| __| \___ \ / _ \033[0m\033[34m\| | | |___ \\033[0m"
echo  "\033[34m| |_| |_   ___) | (_) |\033[0m\033[35m |_| |___) |\033[0m"
echo  "\033[34m \__|\__| |____/\033[0m\033[35m \___/ \___/|____/ \033[0m"
echo  "\033[34m恭喜你，甜糖已于$(date +'%F %T')成功启动！新人填写甜糖邀请码：\033[37m203652\033[0m\033[34m即可获得15张加成卡\033[0m"
echo  "\033[41;33m甜糖官方QQ群:976784785   如需帮助可加QQ:2354791690寻求帮助，加QQ麻烦备注（甜糖）谢谢!\033[0m"