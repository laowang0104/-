#!/usr/bin/env bash
mount /dev/sda1 /mnt
