#!/usr/bin/env bash
mkdir /mnt/disk
mount /dev/sda1 /mnt/disk
