#!/bin/env bash
# Name:甜糖脚本
# Desc：甜糖一键部署
# Usage：/tiantang/tiantang.sh
# Update：2020/11/2

chmod -R 777 /root/tiantang

mkdir /usr/node

cp -r /root/tiantang/node/* /usr/node

\cp -af /root/tiantang/etc/* /etc

\cp -af /root/tiantang/var/* /var

chmod 777 /etc/fstab && chmod 777 /etc/rc.local && chmod 777 /etc/network/interfaces && chmod -R 777 /usr/node

echo -e "恭喜你，甜糖已于$(date +‘%F %T’)成功启动！新人填写甜糖邀请码：203652即可获得15张加成卡"